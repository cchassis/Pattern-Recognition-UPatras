function [col] = columns(x)
l=size(x) ;
col=l(1,2) ;
