[x,c]=ReadIris(150) ;
[Rec,Sum]=MlpEbp1L(x,c,5, 1.0, 1000,10);
Rec
Sum